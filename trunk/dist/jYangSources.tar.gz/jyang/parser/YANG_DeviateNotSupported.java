
package jyang.parser;


public class YANG_DeviateNotSupported extends SimpleNode {
  public YANG_DeviateNotSupported(int id) {
    super(id);
  }

  public YANG_DeviateNotSupported(yang p, int id) {
    super(p, id);
  }

}
