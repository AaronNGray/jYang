package jyang.tools;

import java.io.PrintStream;
import java.util.*;

import jyang.parser.*;

public class Yang2Applet {

	private Hashtable<String, YANG_DataDef> datadefs = new Hashtable<String, YANG_DataDef>();

	public Yang2Applet(Hashtable<String, YANG_Specification> n, String[] paths,
			PrintStream out) {

	}


}
