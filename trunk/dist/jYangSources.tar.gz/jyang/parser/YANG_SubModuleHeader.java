package jyang.parser;


public class YANG_SubModuleHeader extends SimpleNode {
  public YANG_SubModuleHeader(int id) {
    super(id);
  }

  public YANG_SubModuleHeader(yang p, int id) {
    super(p, id);
  }

}
