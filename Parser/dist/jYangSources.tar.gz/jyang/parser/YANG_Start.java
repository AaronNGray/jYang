package jyang.parser;


public class YANG_Start extends SimpleNode {
  public YANG_Start(int id) {
    super(id);
  }

  public YANG_Start(yang p, int id) {
    super(p, id);
  }

}
