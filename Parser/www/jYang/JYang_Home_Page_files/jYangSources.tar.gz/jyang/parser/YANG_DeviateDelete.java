package jyang.parser;


public class YANG_DeviateDelete extends YANG_DeviateMustUnique {

	public YANG_DeviateDelete(int id) {
		super(id);
	}

	public YANG_DeviateDelete(yang p, int id) {
		super(p, id);
	}

}
